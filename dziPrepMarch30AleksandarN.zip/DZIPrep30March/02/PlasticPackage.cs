﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02
{
    public class PlasticPackage : Package
    {
        public  bool IsRecyclable { get; set; }

        public override double CalculatePrice()
        {
            if (!IsRecyclable)
            {
                return 0.50 * base.CalculatePrice() + base.CalculatePrice();
            }
            return base.CalculatePrice();
        }

        public override string GetInfo()
        {
            return $"Plastic package, recyclable: yes/no, weight: {Weight} kg | Price: {CalculatePrice():f2}";
        }
    }
}
