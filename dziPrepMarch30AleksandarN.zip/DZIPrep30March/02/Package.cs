﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02
{
    public abstract class Package
    {
        public  double Weight { get; set; }

        public virtual double CalculatePrice()
        {
            return Weight * 2;
        }

        public virtual string GetInfo()
        {
            return $"weight: {Weight} kg";
        }
    }
}
