﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02
{
    public class CardboardPackage : Package
    {
        public  int LayersCount { get; set; }

        public override double CalculatePrice()
        {
            if(LayersCount > 3)
            {
                return 0.20 * base.CalculatePrice() + base.CalculatePrice();
            }
            return base.CalculatePrice();
        }

        public override string GetInfo()
        {
            return $"Cardboard package, layers: {this.LayersCount}, weight: {this.Weight} kg | Price: {CalculatePrice():f2}";
        }
    }
}
