﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02
{
    public class GlassPackage : Package
    {
        public  bool  IsFragile { get; set; }

        public override double CalculatePrice()
        {
            if (IsFragile)
            {
                return 0.30 * base.CalculatePrice() + base.CalculatePrice();
            }
            return base.CalculatePrice();
        }

        public override string GetInfo()
        {
            string yesNo = "";
            if (!IsFragile)
            {
                yesNo = "no";
            }
            else
            {
                yesNo = "yes";
            }
                return $"Glass package, fragile: {yesNo}, weight: {Weight} kg | Price: {CalculatePrice():f2}";
        }
    }
}
