﻿
using _02;
using System.Transactions;

var packages = new List<Package>();

string input = "";

Console.WriteLine("===== MENU ===== ");
Console.WriteLine("1) Add CardboardPackage");
Console.WriteLine("2) Add PlasticPackage");
Console.WriteLine("3) Add GlassPackage");
Console.WriteLine("4) Show all packages");
Console.WriteLine("5) Show total price");
Console.WriteLine("6) Exit");
Console.WriteLine("Choose option:");

while ((input = Console.ReadLine()) != "6")
{
    switch (input)
    {
        case "1":
            Console.Write("Enter weight: ");
            double weight = double.Parse(Console.ReadLine());
            Console.Write("Enter layers count: ");
            var layers  = int.Parse(Console.ReadLine());

            CardboardPackage cardboardPackage = new CardboardPackage()
            {
                Weight = weight,
                LayersCount = layers
            };

            packages.Add(cardboardPackage);

            Console.WriteLine("Cardboard package added successfully.");
            break;

        case "2":
            Console.Write("Enter weight: ");
            double pweight = double.Parse(Console.ReadLine());
            Console.Write("Is recyclable? (1 = yes, 0 = no): ");
            int isRecyclableInt = int.Parse(Console.ReadLine());

            bool isRec = isRecyclableInt == 1 ? true : false;

            PlasticPackage plasticPackage = new PlasticPackage()
            {
                Weight = pweight,
                IsRecyclable = isRec
            };

            packages.Add(plasticPackage);

            Console.WriteLine("Plastic package added successfully. ");
            break;

        case "3":
            Console.Write("Enter weight: ");
            double gweight = double.Parse(Console.ReadLine());
            Console.Write("Is fragile? (1 = yes, 0 = no): ");
            int isFragileInt = int.Parse(Console.ReadLine());

            bool isFrag = isFragileInt == 1 ? true : false;

            PlasticPackage glassPackage = new PlasticPackage()
            {
                Weight = gweight,
                IsRecyclable = isFrag
            };

            packages.Add(glassPackage);

            Console.WriteLine("Glass package added successfully. ");
            break;

        case "4":
            var cardBoardPacks = packages
                .Where(p=>p is CardboardPackage) 
                .ToList();

            var plasticPacks = packages
               .Where(p => p is PlasticPackage)
               .ToList();

            var glassPacks = packages
               .Where(p => p is GlassPackage)
               .ToList();

            Console.WriteLine("Packages list: ");
            if (cardBoardPacks.Any())
            {
                foreach(var cardboardPack in cardBoardPacks)
                {
                    Console.WriteLine(cardboardPack.GetInfo());
                }
            }

            if (plasticPacks.Any())
            {
                foreach (var item in plasticPacks)
                {
                    Console.WriteLine(item.GetInfo());
                }
            }

            if (glassPacks.Any())
            {
                foreach (var item in glassPacks)
                {
                    Console.WriteLine(item.GetInfo());
                }
            }

            break;

        case "5":
            var cbp = packages
                .Where(p => p is CardboardPackage)
                .Sum(p=>p.CalculatePrice());

            var pp = packages
               .Where(p => p is PlasticPackage)
               .Sum(p => p.CalculatePrice());

            var gp = packages
               .Where(p => p is GlassPackage)
               .Sum(p => p.CalculatePrice());

            double sum = cbp + pp + gp;

            Console.WriteLine($"Total price of all packages: {sum:f2} ");
            break;

        case "6":
            return;
            break;

        default:
            Console.WriteLine("Invalid input!");
            break;
    }


    Console.WriteLine("===== MENU ===== ");
    Console.WriteLine("1) Add CardboardPackage");
    Console.WriteLine("2) Add PlasticPackage");
    Console.WriteLine("3) Add GlassPackage");
    Console.WriteLine("4) Show all packages");
    Console.WriteLine("5) Show total price");
    Console.WriteLine("6) Exit");
    Console.WriteLine("Choose option:");
}
