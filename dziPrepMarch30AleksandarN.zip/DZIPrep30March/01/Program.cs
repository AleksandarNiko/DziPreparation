﻿
try
{
    var epsilon = double.Parse(Console.ReadLine());

    if (epsilon <= 0 || epsilon >= 0.01)
    {
        throw new ArgumentException("Invalid epsilon value.");
    }

    double sum = 0.0;
    int n = 1;
    double term;

    do
    {
        term = 1.0 / (n * (n + 1));
        sum += term;
        n++;
    }
    while (term >= epsilon);

    Console.WriteLine($"Sum: {sum:f2}");
}
catch (Exception e)
{
    Console.WriteLine(e.Message);
}