CREATE DATABASE HolidaysDb;

USE HolidaysDb;

CREATE TABLE Holidays(
id INT PRIMARY KEY IDENTITY,
[name] VARCHAR(100) NOT NULL,
holiday_date DATE,
[type] VARCHAR(50),
[description] VARCHAR(255)
)

CREATE TABLE People(
id INT PRIMARY KEY IDENTITY,
first_name VARCHAR(50) NOT NULL,
last_name VARCHAR(50) NOT NULL,
birth_date DATE,
email VARCHAR(100)
)

CREATE TABLE holiday_people(
id INT PRIMARY KEY IDENTITY,
holidayId INT
FOREIGN KEY (holidayId) REFERENCES Holidays(id),
personId INT
FOREIGN KEY (personId) REFERENCES People(id),
[role] VARCHAR(50)
)

CREATE TABLE Parties(
id INT PRIMARY KEY IDENTITY,
holidayId INT
FOREIGN KEY (holidayId) REFERENCES Holidays(id),
[location] VARCHAR(100),
party_date DATETIME,
theme VARCHAR(100)
)
INSERT INTO holidays (name, holiday_date, type, description) VALUES 

('New Year', '2026-01-01', 'National', 'Celebration of the New Year'), 

('Valentine''s Day', '2026-02-14', 'International', 'Day of love and romance'), 

('Easter', '2026-04-12', 'Religious', 'Christian holiday celebrating resurrection'), 

('Labor Day', '2026-05-01', 'National', 'International Workers'' Day'), 

('Independence Day', '2026-07-04', 'National', 'National independence celebration'), 

('Halloween', '2026-10-31', 'Traditional', 'Costumes and spooky celebrations'), 

('Thanksgiving', '2026-11-26', 'Traditional', 'Family gathering and gratitude'), 

('Christmas Eve', '2026-12-24', 'Religious', 'Family dinner before Christmas'), 

('Christmas Day', '2026-12-25', 'Religious', 'Gift giving and celebrations'), 

('Birthday Party', '2026-06-15', 'Personal', 'Private birthday celebration'); 
INSERT INTO people (first_name, last_name, birth_date, email) VALUES 

('John', 'Smith', '1995-02-14', 'john.smith@example.com'), 

('Emma', 'Johnson', '1998-07-03', 'emma.johnson@example.com'), 

('Michael', 'Brown', '1992-11-21', 'michael.brown@example.com'), 

('Sophia', 'Davis', '2000-01-09', 'sophia.davis@example.com'), 

('Daniel', 'Miller', '1997-05-30', 'daniel.miller@example.com'), 

('Olivia', 'Wilson', '1994-09-12', 'olivia.wilson@example.com'), 

('James', 'Taylor', '1990-03-18', 'james.taylor@example.com'), 

('Emily', 'Anderson', '1999-12-02', 'emily.anderson@example.com'), 

('William', 'Thomas', '1993-08-25', 'william.thomas@example.com'), 

('Isabella', 'Moore', '2001-06-07', 'isabella.moore@example.com'); 
INSERT INTO holiday_people (holidayId, personId, role) VALUES 

(1, 1, 'organizer'), 

(1, 2, 'guest'), 

(2, 3, 'participant'), 

(3, 4, 'guest'), 

(4, 5, 'guest'), 

(4, 6, 'organizer'), 

(9, 7, 'gift giver'), 

(9, 8, 'gift receiver'), 

(10, 9, 'guest'), 

(10, 10, 'organizer'); 
INSERT INTO parties (holidayId, location, party_date, theme) VALUES 

(1, 'New York - Downtown', '2025-12-31T21:00:00', 'Starry Night'), 

(2, 'Paris - Restaurant', '2026-02-14T20:00:00', 'Romantic Dinner'), 

(3, 'London - Family Home', '2026-04-12T13:00:00', 'Easter Lunch'), 

(4, 'Berlin - City Square', '2026-05-01T11:00:00', 'Workers Celebration'), 

(5, 'Washington - Backyard', '2026-07-04T18:00:00', 'BBQ Party'), 

(6, 'Los Angeles - Club', '2026-10-31T22:00:00', 'Halloween Costume Party'), 

(7, 'Chicago - Family House', '2026-11-26T15:00:00', 'Thanksgiving Dinner'), 

(8, 'Rome - Apartment', '2026-12-24T20:00:00', 'Family Gathering'), 

(9, 'Madrid - Living Room', '2026-12-25T12:00:00', 'Christmas Celebration'), 

(10, 'Sofia - Garden', '2026-06-15T18:00:00', 'Birthday Party'); 

--1
SELECT h.[name],h.holiday_date, p.[location], p.party_date
FROM Holidays as h
JOIN Parties as p on h.id = p.holidayId;

--2
SELECT p.first_name, p.last_name, h.[name] as [holiday_name]
FROM People as p
JOIN holiday_people as hp on hp.personId = p.id
JOIN Holidays as h on hp.holidayId=h.id

--3
SELECT p.first_name, p.last_name, h.[name] as [holiday_name], hp.[role]
FROM People as p
JOIN holiday_people as hp on hp.personId = p.id
JOIN Holidays as h on hp.holidayId=h.id

--5
SELECT h.[name], p.[location], p.party_date
FROM Holidays as h
JOIN Parties as p on h.id = p.holidayId
WHERE h.type = 'Religious'

--6
SELECT p.first_name, p.last_name, h.[name] as [holiday_name]
FROM People as p
JOIN holiday_people as hp on hp.personId = p.id
JOIN Holidays as h on hp.holidayId=h.id
WHERE p.birth_date > '1996-05-12'

--7
SELECT p.first_name, p.last_name, h.[name] as [holiday_name], h.holiday_date
FROM People as p
JOIN holiday_people as hp on hp.personId = p.id
JOIN Holidays as h on hp.holidayId=h.id
ORDER BY h.holiday_date ASC

--8
SELECT h.[name], p.[location], h.holiday_date
FROM Holidays as h
JOIN Parties as p on h.id = p.holidayId
ORDER BY p.party_date DESC

--9
SELECT p.first_name, p.last_name, h.[name] as [holiday_name], hp.[role]
FROM People as p
JOIN holiday_people as hp on hp.personId = p.id
JOIN Holidays as h on hp.holidayId=h.id
WHERE p.last_name LIKE 'T%';

--10
SELECT h.[name], h.[description] ,p.[location]
FROM Holidays as h
JOIN Parties as p on h.id = p.holidayId
WHERE h.[description] LIKE '%family%';

--11
SELECT h.[name],p.[location], p.party_date
FROM Holidays as h
JOIN Parties as p on h.id = p.holidayId
WHERE p.[location] LIKE '%Home%';

--12
SELECT TOP(3) h.[name],p.[location], p.party_date
FROM Holidays as h
JOIN Parties as p on h.id = p.holidayId
ORDER BY p.party_date DESC

--13
SELECT h.[name] AS holiday_name, COUNT(hp.personId) AS participants_count
FROM holidays h
JOIN holiday_people hp ON h.id = hp.holidayId
GROUP BY h.name
ORDER BY participants_count DESC;