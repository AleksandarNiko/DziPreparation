﻿
char[] symbols = Console.ReadLine()
    .Split()
    .Select(char.Parse)
    .ToArray();

int k = int.Parse(Console.ReadLine());

var combinations = GetCombinations(symbols, k);

static List<string> GetCombinations(char[] symbols, int k)
{
    if (k > symbols.Length)
    {
        throw new ArgumentException("k should be less than n.");
    }

    var results = new List<string>();
    int n = symbols.Length;

   
    var stack = new int[k];      
    var next = new int[k];        
    var used = new bool[n];
    int depth = 0;

    for (int i = 0; i < k; i++) 
    { 
        next[i] = 0; 
    }

    while (depth >= 0)
    {
        if (depth == k)
        {
            var chars = new char[k];
            
            for (int j = 0; j < k; j++)
            { 
                chars[j] = symbols[stack[j]];
            }
            
            results.Add(new string(chars));

            depth--;
            if (depth >= 0)
            {
                used[stack[depth]] = false;
            }
            continue;
        }

        if (next[depth] >= n)
        {
            next[depth] = 0;
            depth--;
            if (depth >= 0)
            {
                used[stack[depth]] = false;
            }
            continue;
        }

        int i = next[depth];
        next[depth] = i + 1;

        if (used[i])
        { 
            continue;
        }

        if (depth == 0 && char.IsDigit(symbols[i]))
        { 
            continue;
        } 

        stack[depth] = i;
        used[i] = true;
        depth++;
    }

    return results;
}
