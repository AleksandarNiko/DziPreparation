﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03
{
    public abstract class JobOffer
    {
        private string jobTitle;
        private string company;
        private double salary;

        public JobOffer(string jobTitle, string company, double salary)
        {
            JobTitle = jobTitle;
            Company = company;
            Salary = salary;
        }

        public string JobTitle { get => jobTitle; set 
            {
                if (value.Length < 3 || value.Length > 30)
                {
                    throw new Exception("JobTitle should be between 3 and 30 characters!");
                }
                jobTitle = value;
            } }

        public string Company { get => company; set
            {
                if (value.Length < 3 || value.Length > 30)
                {
                    throw new Exception("Company should be between 3 and 30 characters!");
                }
                company = value;
            }
        } 

        public double Salary { get => salary; set 
            {
                if(value<0)
                {
                    throw new Exception("Salary should be 0 or positive!");
                }
                salary = value;
            } }

        public override string ToString()
        {
            var sb = new StringBuilder();

            sb.AppendLine($"Job Title: {JobTitle}");
            sb.AppendLine($"Company: {Company}");
            sb.AppendLine($"Salary: {Salary:f2} BGN");

            return sb.ToString();
        }
    }
}
