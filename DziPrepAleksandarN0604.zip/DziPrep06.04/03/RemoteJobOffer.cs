﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03
{
    public class RemoteJobOffer : JobOffer
    {
        public RemoteJobOffer(string jobTitle, string company, double salary, bool fullyRemote) : base(jobTitle, company, salary)
        {
            FullyRemote = fullyRemote;
        }

        public  bool FullyRemote { get; set; }

        public override string ToString()
        {
            string fremote = FullyRemote ? "yes" : "no";
            var sb = new StringBuilder();

            sb.AppendLine($"Job Title: {JobTitle}");
            sb.AppendLine($"Company: {Company}");
            sb.AppendLine($"Salary: {Salary:f2} BGN");
            sb.AppendLine($"Fully Remote: {fremote} ");

            return sb.ToString();
        }
    }
}
