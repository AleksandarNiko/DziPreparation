﻿
using _03;

string path = "offers.txt";

var offers = new List<JobOffer>();

using (StreamReader reader = new StreamReader(path))
{
    string line;
    while ((line = reader.ReadLine()) != null)
    {
        string[] parts = line.Split("|", StringSplitOptions.RemoveEmptyEntries);
        string lastPart = parts[parts.Length - 1].Trim();
        if (lastPart == "False" || lastPart == "True")
        {
            bool fullyRemote = bool.Parse(lastPart);
            var offer = new RemoteJobOffer(parts[0].Trim(), parts[1].Trim(), double.Parse(parts[2].Trim()), fullyRemote);
            offers.Add(offer);

        }
        else
        {
            var offer = new OnSiteJobOffer(parts[0].Trim(), parts[1].Trim(), double.Parse(parts[2].Trim()), lastPart);
            offers.Add(offer);
        }
    }
}

Console.WriteLine("----MENU----");
Console.WriteLine("1. AllOffers – извежда пълна информация за всички оферти в посочения формат;");
Console.WriteLine("2. GetOffersSalary – извежда средната заплата за всеки от видовете работа (дистанционна/присъствена) подредени по низходящ ред по заплати");
Console.WriteLine("3. GetOffersWithoutSalary – извежда всички оферти без обявени заплати (salary=0), подредени в азбучен ред по име на компанията");
Console.WriteLine("4. GetoffersTrue – извежда броя на офертите само за дистанционна работа");
Console.WriteLine("5. SearchCity – при тази команда, от клавиатурата се въвежда име на град и се извеждат всички оферти за него.");
Console.WriteLine("6. MaxsSalary – извежда офертата с най-висока заплата.");
Console.WriteLine("7. Stop");
Console.WriteLine();
Console.Write("Choose option: ");

string command = "";

while((command= Console.ReadLine()) != "7")
{
    switch (command)
    {
        case "1":
            foreach (var offer in offers)
            {
                Console.WriteLine(offer.ToString());
            }
            break;
        case "2":
            var remoteOffers = offers.OfType<RemoteJobOffer>();
            var onSiteOffers = offers.OfType<OnSiteJobOffer>();
            double avgRemoteSalary = remoteOffers.Any() ? remoteOffers.Average(o => o.Salary) : 0;
            double avgOnSiteSalary = onSiteOffers.Any() ? onSiteOffers.Average(o => o.Salary) : 0;
            Console.WriteLine($"Average Remote Salary: {avgRemoteSalary:f2} BGN");
            Console.WriteLine($"Average On-Site Salary: {avgOnSiteSalary:f2} BGN");
            break;
        case "3":
            var offersWithoutSalary = offers.Where(o => o.Salary == 0).OrderBy(o => o.Company);
            foreach (var offer in offersWithoutSalary)
            {
                Console.WriteLine(offer.ToString());
            }
            break;
        case "4":
            int remoteCount = offers.OfType<RemoteJobOffer>().Count();
            Console.WriteLine($"Number of Remote Offers: {remoteCount}");
            break;
        case "5":
            Console.Write("Enter city name: ");
            string cityName = Console.ReadLine();
            var cityOffers = offers.OfType<OnSiteJobOffer>().Where(o => o.City.Equals(cityName, StringComparison.OrdinalIgnoreCase));
            foreach (var offer in cityOffers)
            {
                Console.WriteLine(offer.ToString());
            }
            break;
        case "6":
            var maxSalaryOffer = offers.OrderByDescending(o => o.Salary).FirstOrDefault();
            if (maxSalaryOffer != null)
            {
                Console.WriteLine("Offer with the highest salary:");
                Console.WriteLine(maxSalaryOffer.ToString());
            }
            else
            {
                Console.WriteLine("No offers available.");
            }
            break;
        default:
            Console.WriteLine("Invalid option. Please try again.");
            break;
    }
    Console.Write("Choose option: ");
}