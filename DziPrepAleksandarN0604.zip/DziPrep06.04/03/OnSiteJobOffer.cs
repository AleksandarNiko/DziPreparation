﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03
{
    public class OnSiteJobOffer : JobOffer
    {
        private string city;

        public OnSiteJobOffer(string jobTitle, string company, double salary, string city) : base(jobTitle, company, salary)
        {
            City = city;

        }

        public string City { get => city; set
            {
                if (value.Length < 3 || value.Length > 30)
                {
                    throw new Exception("City should be between 3 and 30");
                }
                city = value;
            }
        }

        public override string ToString()
        {
            var sb = new StringBuilder();

            sb.AppendLine($"Job Title: {JobTitle}");
            sb.AppendLine($"Company: {Company}");
            sb.AppendLine($"Salary: {Salary:f2} euro");
            sb.AppendLine($"City: {City}");

            return sb.ToString();
        }
    }
}
