
CREATE DATABASE FoodsMoods;

USE FoodsMoods;

CREATE TABLE Users(
[user_id] INT PRIMARY KEY IDENTITY,
username VARCHAR(50) NOT NULL,
age INT CHECK (age > 0),
gender CHAR(1) NOT NULL,
CONSTRAINT CHK_Pol CHECK (gender IN ('M', 'F'))
)

create table Foods(
food_id int primary key identity,
[name] varchar(100) not null,
category varchar(50),
calories int
)

create table Moods(
mood_id int primary key identity,
mood_name varchar(50) not null
)

create table Consumptions(
consumption_id int primary key identity,
[user_id] int not null,
food_id int not null,
mood_id int not null,
[date] DATE

FOREIGN KEY([user_id]) REFERENCES Users([user_id]),
FOREIGN KEY(food_id) REFERENCES Foods(food_id),
FOREIGN KEY(mood_id) REFERENCES Moods(mood_id),
)

insert into Users values
('ivan123',25,'M'), 
('maria45', 30, 'F'), 
('georgi88', 22, 'M'), 
('ani_ivanova', 28, 'F'), 
('tedyBear', 24, 'F'), 
('miroBig', 27, 'M') 

insert into Foods values
('Apple','Fruit',52),
('Pizza','Fast Food',285),
('Chocolate','Dessert',546),
('Salad', 'Vegetable', 150)

insert into Moods values
('Happy'),
('Sad'),
('Energetic'),
('Tired')

INSERT INTO Consumptions ( user_id, food_id, mood_id, date) VALUES 

( 1, 2, 1, '2025-05-01'), 

(1, 3, 1, '2025-05-02'), 

( 2, 1, 3, '2025-05-01'), 

( 2, 4, 4, '2025-05-03'), 

( 3, 2, 2, '2025-05-02'), 

( 3, 3, 1, '2025-05-04'), 

( 4, 1, 3, '2025-05-01'), 

( 4, 4, 1, '2025-05-02'); 

--1
SELECT TOP(1) f.[name]
from foods as f
join Consumptions as c on f.food_id = c.food_id
join Moods as m on c.mood_id = m.mood_id
where m.mood_name='Happy'
ORDER BY (m.mood_id) DESC

--2
SELECT u.username, AVG(f.calories) AS avg_calories
FROM Users u
JOIN Consumptions c ON u.[user_id] = c.[user_id]
JOIN Foods f ON c.food_id = f.food_id
GROUP BY u.username

--3
select u.username
from Users as u
join Consumptions c ON u.[user_id] = c.[user_id]
where c.consumption_id is null

--4
SELECT u.username, AVG(f.calories) AS avg_calories
FROM Users u
JOIN Consumptions c ON u.[user_id] = c.[user_id]
JOIN Foods f ON c.food_id = f.food_id
GROUP BY u.username

--5
select u.username, COUNT(c.consumption_id) AS consumption_count
from Users as u
join Consumptions c ON u.[user_id] = c.[user_id]
group by u.username
having count(c.consumption_id) >= 2

--6
UPDATE Foods
SET calories= calories+calories*0.1 
where category = 'Dessert';